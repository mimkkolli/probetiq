const toggle = document.querySelector(".hamb-menu");
ul = document.querySelector("ul");
imgBox = document.querySelector(".imgBox");
slides = imgBox.getElementsByTagName("img");
contentBox = document.querySelector(".hero-content");
texts = contentBox.getElementsByTagName("div");
cardsBox = document.querySelector(".cards");

let i = 0;

let data = [
  {
    id: 1,
    title: "SOCCER",
    desc:
      "When it comes to making predictions in the world of sports, why take chances when you can let the professionals do it for you? With years of experience and an in-depth understanding of the game, these experts have the knowledge and expertise to provide accurate and reliable predictions that can help you make informed decisions.",
    link: "bets/double-chance-predictions/index1.html",
    image:
      "stadiumphoto-643632382-170667a(1).png",
    appearance:
      " Be Gamble Aware, Bet Responsibly",
    occurrence:
      " You Must Be 18 Years Old Or Over To Use This Site. Please Bet Responsibly.",
    mythology:
      " Be Gamble Aware, Bet Responsibly"
  },

  {
    id: 2,
    title: "BASKETBALL",
    desc:
      "Whether you're a casual fan looking to place a bet or a seasoned gambler seeking the edge, the professionals can help you stay ahead of the curve. With access to the latest stats, trends, and insider information, they can help you make the most informed predictions possible.",
    link: "bets/double-chance-predictions/basketball-tips.html",
    image:
      "basketball-image02.png",
    appearance:
      "You Must Be 18 Years Old Or Over To Use This Site. Please Bet Responsibly.",
    occurrence:
      "You Must Be 18 Years Old Or Over To Use This Site. Please Bet Responsibly.",
    mythology:
      "Be Gamble Aware, Bet Responsibly"
  },

  {
    id: 3,
    title: "ICE HOCKEY",
    desc:
      "So why waste time trying to second-guess the outcome of a game or the performance of a player when you can let the professionals handle it for you? With their expertise, you can feel confident in your predictions and make the most of your bets and investments.",
    link: "bets/double-chance-predictions/Icehockey-tips.html",
    image:
      "ice_hockey_images(01).png",
    appearance:
      "You Must Be 18 Years Old Or Over To Use This Site. Please Bet Responsibly.",
    occurrence:
      "Be Gamble Aware, Bet Responsibly",
    mythology:
      "Be Gamble Aware, Bet Responsibly"
  },

  {
    id: 4,
    title: "Become Switch partner now",
    desc:
      "With Interswitch POS terminals, businesses can accept a variety of payment methods including credit and debit cards, mobile payments, and electronic transfers. This ensures that customers have a range of options to choose from, making transactions more convenient and efficient for all parties involved.",
    link: "cricket-tips/index.html",
   
    image:
      "png_20230410_213734_0000.png",
    appearance:
      "Be Gamble Aware, Bet Responsibly",
    occurrence:
      "You Must Be 18 Years Old Or Over To Use This Site. Please Bet Responsibly.",
    mythology:
      "Be Gamble Aware, Bet Responsibly"
  }
];

toggle.addEventListener("click", () => {
  toggle.classList.toggle("active");
  ul.classList.toggle("active");
});

function setup() {
  let images = "";
  let content = "";
  let cards = "";

  data.forEach((item, index) => {
    images += `<img src="${item.image}" class="${
      index === 0 ? "active" : ""
    }">`;
    content += `<div class="${index === 0 ? "active" : ""}"><h1>${
      item.title
    }</h1><p>${item.desc}</p><a href="${
      item.link
    }" target="_blank">GET STARTED</a></div>`;
    cards += `<div class="card" onclick="setSlide(${index})"><div class="card-img-wrapper"><img src="${item.image}"></div><h2>${item.title}</h2></div>`;
  });

  imgBox.innerHTML = images;
  contentBox.innerHTML = content;
  cardsBox.innerHTML = cards;
}

setup();

function toggleModal(info) {
  const popup = document.getElementById("popup-detail");
  const para = popup.getElementsByTagName("p")[0];

  popup.classList.toggle("active");

  switch (info) {
    case "vzhled":
      para.innerText = data[i].appearance;
      break;
    case "vyskyt":
      para.innerText = data[i].occurrence;
      break;
    case "mytologie":
      para.innerText = data[i].mythology;
      break;
  }
}

function toggleModalAll() {
  const popup = document.getElementById("popup-all");
  popup.classList.toggle("active");
}

function nextSlide() {
  index = (i + 1) % slides.length;

  setSlide(index);
}

function prevSlide() {
  index = (i - 1 + slides.length) % slides.length;

  setSlide(index);
}

function setSlide(index) {
  const popup = document.getElementById("popup-all");
  popup.classList.remove("active");

  slides[i].classList.remove("active");
  texts[i].classList.remove("active");

  i = index;

  slides[i].classList.add("active");
  texts[i].classList.add("active");
}